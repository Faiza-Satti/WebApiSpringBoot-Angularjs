package com.example.demo.service;

import com.example.demo.entity.Person;
import com.example.demo.entity.User;
import com.example.demo.repository.PersonRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public List<User> getUsers(String username, String password){

        return userRepository.findAll(username,password);
    }

    public User getUser(int id){

        return userRepository.findById(id).orElse(null);
    }

    //registering user
    public User addUser(User user){

        userRepository.save(user);
        return user;
    }
//    public Person updatePerson(int id,Person person){
//        //person.setID(id);
//        personRepository.save(person);
//        return person;
//    }
//    public void deletePerson(int id){
//
//        personRepository.deleteById(id);
//    }
}
